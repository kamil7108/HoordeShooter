# HordeShooter

Game created by: Kamil Machulik and Patryk Lipka
controls:
arrows- movement
space- shooting
z/x- changing weapons (unlock them by finishing rounds)

Weapons are upgraded after beating further rounds
